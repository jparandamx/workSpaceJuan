* Must use JBDS throughout
* Short videos - 5 mins max
* Start with new Java Project
* See <https://docs.jboss.org/author/display/AS71/Writing+a+quickstart> for now TODO Unify these.
