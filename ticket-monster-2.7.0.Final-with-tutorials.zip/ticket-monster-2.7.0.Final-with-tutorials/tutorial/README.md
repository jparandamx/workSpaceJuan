What is this?
=============

This is a series of tutorials that will walk you through the process of creating the TicketMonster application from end to end.

For now, just browse clone the git repo, read CONTRIBUTING.md and run `./generate.sh` - GitHub doesn't process asciidoc very well!
